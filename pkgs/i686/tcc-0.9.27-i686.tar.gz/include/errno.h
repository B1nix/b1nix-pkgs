#ifndef B1NIX_U_ERRNO_H
#define B1NIX_U_ERRNO_H

#ifdef __cplusplus
extern "C" {
#endif

extern int errno;

/* Normalize kernel error codes to valid POSIX errno values.
   Returns EIO for out-of-range codes. */
int normalize_errno(long rc);

#ifdef __cplusplus
}
#endif

#define EPERM            1      /* Operation not permitted */
#define ENOENT           2      /* No such file or directory */
#define ESRCH            3      /* No such process */
#define EINTR            4      /* Interrupted system call */
#define EIO              5      /* I/O error */
#define ENXIO            6      /* No such device or address */
#define E2BIG            7      /* Argument list too long */
#define ENOEXEC          8      /* Exec format error */
#define EBADF            9      /* Bad file number */
#define ECHILD          10      /* No child processes */
#define EAGAIN          11      /* Try again */
#define EWOULDBLOCK     EAGAIN
#define ENOMEM          12      /* Out of memory */
#define EACCES          13      /* Permission denied */
#define EFAULT          14      /* Bad address */
#define ENOTBLK         15      /* Block device required */
#define EBUSY           16      /* Device or resource busy */
#define EEXIST          17      /* File exists */
#define EXDEV           18      /* Cross-device link */
#define ENODEV          19      /* No such device */
#define ENOTDIR         20      /* Not a directory */
#define EISDIR          21      /* Is a directory */
#define EINVAL          22      /* Invalid argument */
#define ENFILE          23      /* File table overflow */
#define EMFILE          24      /* Too many open files */
#define ENOTTY          25      /* Not a typewriter */
#define ETXTBSY         26      /* Text file busy */
#define EFBIG           27      /* File too large */
#define ENOSPC          28      /* No space left on device */
#define ESPIPE          29      /* Illegal seek */
#define EROFS           30      /* Read-only file system */
#define EMLINK          31      /* Too many links */
#define EPIPE           32      /* Broken pipe */
#define EDOM            33      /* Math argument out of domain */
#define ERANGE          34      /* Math result not representable */
#define ENAMETOOLONG    36      /* File name too long */
#define ENOSYS          38      /* Function not implemented */
#define ENOTEMPTY       39      /* Directory not empty */
#define ELOOP           40      /* Too many symbolic links */
#define ENOTSOCK        88      /* Socket operation on non-socket */
#define EDESTADDRREQ    89      /* Destination address required */
#define EMSGSIZE        90      /* Message too long */
#define EPROTOTYPE      91      /* Protocol wrong type for socket */
#define EPROTO          71      /* Protocol error */
#define ENOPROTOOPT     92      /* Protocol not available */
#define EPROTONOSUPPORT 93      /* Protocol not supported */
#define ESOCKTNOSUPPORT 94      /* Socket type not supported */
#define EOPNOTSUPP      95      /* Operation not supported */
#define ENOTSUP         EOPNOTSUPP
#define EPFNOSUPPORT    96      /* Protocol family not supported */
#define EAFNOSUPPORT    97      /* Address family not supported */
#define EADDRINUSE      98      /* Address already in use */
#define EADDRNOTAVAIL   99      /* Cannot assign requested address */
#define ENETDOWN        100     /* Network is down */
#define ENETUNREACH     101     /* Network is unreachable */
#define ENETRESET       102     /* Network dropped connection */
#define ECONNABORTED    103     /* Software caused connection abort */
#define ECONNRESET      104     /* Connection reset by peer */
#define ENOBUFS         105     /* No buffer space available */
#define EISCONN         106     /* Transport endpoint is already connected */
#define ENOTCONN        107     /* Transport endpoint is not connected */
#define ETIMEDOUT       110     /* Connection timed out */
#define ECONNREFUSED    111     /* Connection refused */
#define EHOSTUNREACH    113     /* No route to host */
#define EALREADY        114     /* Operation already in progress */
#define EINPROGRESS     115     /* Operation now in progress */

#define EDEADLK         35      /* Resource deadlock would occur */
#define ENOLCK          37      /* No record locks available */
#define ENOMSG          42      /* No message of desired type */
#define EILSEQ          84      /* Illegal byte sequence */
#define EOVERFLOW       75      /* Value too large for defined data type */
#define ENODATA         61      /* No data available (no such xattr) */
#ifndef ENOATTR
#define ENOATTR         ENODATA /* No such attribute (BSD spelling) */
#endif

/* Additional POSIX/Linux errno values (Linux x86 ABI numbering). */
#define ECHRNG          44      /* Channel number out of range */
#define EUNATCH         49      /* Protocol driver not attached */
#define ENONET          64      /* Machine is not on the network */
#define ENOPKG          65      /* Package not installed */
#define ENOLINK         67      /* Link has been severed */
#define ECOMM           70      /* Communication error on send */
#define ENOTUNIQ        76      /* Name not unique on network */
#define EBADFD          77      /* File descriptor in bad state */
#define EUSERS          87      /* Too many users */
#define ESHUTDOWN       108     /* Cannot send after transport endpoint shutdown */
#define EHOSTDOWN       112     /* Host is down */
#define ESTALE          116     /* Stale file handle */
#define EISNAM          120     /* Is a named type file */
#define EDQUOT          122     /* Disk quota exceeded */
#define ENOMEDIUM       123     /* No medium found */
#define ECANCELED       125     /* Operation canceled */
#define ENOKEY          126     /* Required key not available */

#endif
