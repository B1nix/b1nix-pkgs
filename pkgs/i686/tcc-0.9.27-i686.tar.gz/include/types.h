#ifndef B1NIX_U_TYPES_H
#define B1NIX_U_TYPES_H

#include <stdint.h>

typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef uintptr_t usize;
typedef intptr_t  isize;

#endif
